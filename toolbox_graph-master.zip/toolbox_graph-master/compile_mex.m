% compile mex file for dijkstra

mex -largeArrayDims mex/perform_dijkstra_propagation.cpp mex/fheap/fib.cpp 